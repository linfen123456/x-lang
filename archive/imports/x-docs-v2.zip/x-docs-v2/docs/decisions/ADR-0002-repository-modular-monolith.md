# ADR-0002 阶段化模块化单体仓库

> 状态：Accepted｜版本：2.1.0｜负责人：Compiler Lead｜最后更新：2026-10-22
> 类型：ADR｜取代：旧 ADR-0002（成员数由“4–6 个”或“恰好 5 个”统一为 5 个，上限 6 个）

## 背景

项目早期最主要的风险是“过早拆分”：空 crate、接口冻结得太早、跨仓库协调成本高。同时又必须防止各层互相污染。

## 决策

1. P0–P2 使用一个 Cargo Workspace，包含 **5 个成员**：`x-compiler`、`x-runtime`、`x-cli`、`x-conformance`、`xtask`。目录与职责见 [repository](../repository.md)。
2. 边界靠**模块分层 + `cargo xtask check-deps` 静态检查**来维持，而不是靠 crate 数量。
3. 新增成员必须满足 [repository](../repository.md) §5 的拆分门禁。成员数超过 6 个时，必须修订本 ADR。
4. 生态包放在独立仓库，只依赖公开 API。

## 备选方案

| 方案 | 不选的原因 |
|---|---|
| 每个概念一个 crate（20 个以上） | 接口过早冻结，编译和协调成本都高 |
| 单个 crate | LLVM 与运行时的隔离不清楚，编译时间也会变长 |

## 后果

- 依赖检查是阻断式 CI 的一部分。
- P3 引入 LSP 时，评估是否拆出 `x-lsp`（理由：独立进程、独立的取消语义）。
